package com.example.database.ui.viewmodel

class PostViewModel {
}