package com.example.database

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.example.database.data.local.dao.PostDao
import com.example.database.data.local.database.AppDatabase
import com.example.database.data.local.entity.PostEntity
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private lateinit var postDao: PostDao

    override  fun onCreate (savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)

        // FIX: The error is likely here. Using 'applicationContext' is the safest way
        // to initialize a database from an Activity.
        db = AppDatabase.getInstance(applicationContext)
        postDao = db.postDao()

        setContent {
            MaterialTheme {
                PostScreen(postDao)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostScreen(postDao: PostDao) {
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<PostEntity>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var editingPost by remember { mutableStateOf<PostEntity?>(null) }

    // Function to refresh the list from the database
    fun refresh() {
        scope.launch {
            // NOTE: postDao.getAll() must be a suspend function in your DAO for this to work.
            posts = postDao.getAll()
        }
    }

    // Load list on initial composition
    LaunchedEffect(Unit) {
        refresh()
    }

    // UI Code (This section was already correct)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CRUD con Room + Compose") }
            )
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(color =
                            MaterialTheme.colorScheme.onSurface),
                        modifier = Modifier
                            .weight(1f)
                            .padding(8.dp),
                        singleLine = true
                    )
                    Button(onClick = {
                        scope.launch {
                            if (editingPost == null) {
                                postDao.insert(PostEntity(content = text))
                            } else {
                                // Update logic
                                postDao.delete(editingPost!!)
                                // Re-inserting, explicitly providing the old ID is safer for Room
                                postDao.insert(PostEntity(id = editingPost!!.id, content = text))
                                editingPost = null
                            }
                            text = ""
                            refresh()
                        }
                    }) {
                        Text(if (editingPost == null) "Agregar" else "Actualizar")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(posts) { post ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors =
                                CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement =
                                    Arrangement.SpaceBetween,
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Text(post.content)
                                Row {
                                    TextButton(onClick = {
                                        text = post.content
                                        editingPost = post
                                    }) {
                                        Text("Editar")
                                    }
                                    TextButton(onClick = {
                                        scope.launch {
                                            postDao.delete(post)
                                            refresh()
                                        }
                                    }) {
                                        Text("Eliminar")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}