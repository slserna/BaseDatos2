package com.example.database.data.repository

class PostRepository {
}